<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SharesController extends Controller
{
    
	 public function index()
	{
	$title="Anju";
	return view('shares.index')->with('name',$title);
	}
	 public function abouts()
	{
	return view('shares.abouts');
	}
	 public function service()
	{
	return view('shares.service');
	}
}
