<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
  public $fillable=['name','mail','phone','username','password'];
}
