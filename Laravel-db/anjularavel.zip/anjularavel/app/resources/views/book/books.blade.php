<html>
<form method="post" action="{{route('book.store')}}">
@csrf
Title:<input type="text" name="title" /><br /><br />
Body:<input type="text" name="body" /><br /><br />
<button type="sumbit" />Add<br />
</form>