<form method="post" action="{{route('employee.update',$employee->id)}}">
@method('PATCH')
@csrf
<label for="name">Name:</label>
<input type="text" name="name" value="{{$employee->name}}" />
<label for="address">Address:</label>
<input type="text" name="address" value="{{$employee->address}}" />
<label for="phone">Phone:</label>
<input type="text" name="phone" value="{{$employee->phone}}" />
<button type="submit">UPDATE</button>
</form>