
<form method="post" action="{{route('employee.store')}}">
@csrf
Name:<input type="text" name="name" /><br /><br />
Addess:<input type="text" name="address" /><br /><br />
Phone:<input type="text" name="phone" /><br /><br />
<button type="sumbit" />Add<br />
</form>