<table border="1">
<head>
<tr>
<td>Id</td>
<td>Name</td>
<td>Address</td>
<td>Phone</td>
</tr>
</head>
<body>
@foreach($employeedetails as $employee)
<tr>
<td>{{$employee->id}}</td>
<td>{{$employee->name}}</td>
<td>{{$employee->address}}</td>
<td>{{$employee->phone}}</td>
<td><a href="{{route('employee.edit',$employee->id)}}">Edit</a></td>
<td><form action="{{route('employee.destroy',$employee->id)}}" method="post">
@csrf
@method('DELETE')
<button type="submit">delete</button>
</form>
</td>
</tr>
@endforeach
</body>
</table>
