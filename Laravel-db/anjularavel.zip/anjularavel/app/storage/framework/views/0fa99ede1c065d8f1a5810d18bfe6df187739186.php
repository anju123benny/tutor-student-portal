<form method="post" action="<?php echo e(route('book.update',$books->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
<label for="name">Title:</label>
<input type="text" name="title" value="<?php echo e($books->title); ?>" />
<label for="price">Body:</label>
<input type="text" name="body" value="<?php echo e($books->body); ?>" />
<button type="submit">UPDATE</button>
</form>