<html>
<form method="post" action="<?php echo e(route('register.store')); ?>">
<?php echo csrf_field(); ?>
Name:<input type="text" name="name" /><br /><br />
mail:<input type="text" name="mail" /><br /><br />
phone:<input type="text" name="phone" /><br /><br />
username:<input type="text" name="username" /><br /><br />
password:<input type="text" name="password" /><br /><br />


<button type="sumbit" />Add<br />
</form>
</html>