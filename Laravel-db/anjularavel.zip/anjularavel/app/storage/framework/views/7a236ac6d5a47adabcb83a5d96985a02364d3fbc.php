
<form method="post" action="<?php echo e(route('employee.store')); ?>">
<?php echo csrf_field(); ?>
Name:<input type="text" name="name" /><br /><br />
Addess:<input type="text" name="address" /><br /><br />
Phone:<input type="text" name="phone" /><br /><br />
<button type="sumbit" />Add<br />
</form>