<table border="1">
<head>
<tr>
<td>Id</td>
<td>Title</td>
<td>Body</td>
</tr>
</head>
<body>
<?php $__currentLoopData = $booksdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($book->id); ?></td>
<td><?php echo e($book->title); ?></td>
<td><?php echo e($book->body); ?></td>
<td><a href="<?php echo e(route('book.edit',$book->id)); ?>">Edit</a></td>
<td><form action="<?php echo e(route('book.destroy',$book->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit">delete</button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</table>
