<form method="post" action="<?php echo e(route('employee.update',$employee->id)); ?>">
<?php echo method_field('PATCH'); ?>
<?php echo csrf_field(); ?>
<label for="name">Name:</label>
<input type="text" name="name" value="<?php echo e($employee->name); ?>" />
<label for="address">Address:</label>
<input type="text" name="address" value="<?php echo e($employee->address); ?>" />
<label for="phone">Phone:</label>
<input type="text" name="phone" value="<?php echo e($employee->phone); ?>" />
<button type="submit">UPDATE</button>
</form>