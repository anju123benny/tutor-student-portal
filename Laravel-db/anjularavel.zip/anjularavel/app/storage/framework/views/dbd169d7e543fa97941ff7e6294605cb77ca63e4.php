<table border="1">
<head>
<tr>
<td>Id</td>
<td>Name</td>
<td>Address</td>
<td>Phone</td>
</tr>
</head>
<body>
<?php $__currentLoopData = $employeedetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($employee->id); ?></td>
<td><?php echo e($employee->name); ?></td>
<td><?php echo e($employee->address); ?></td>
<td><?php echo e($employee->phone); ?></td>
<td><a href="<?php echo e(route('employee.edit',$employee->id)); ?>">Edit</a></td>
<td><form action="<?php echo e(route('employee.destroy',$employee->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit">delete</button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</table>
