import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnComponent } from './an.component';

describe('AnComponent', () => {
  let component: AnComponent;
  let fixture: ComponentFixture<AnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
