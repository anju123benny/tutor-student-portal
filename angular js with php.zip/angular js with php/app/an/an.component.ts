import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-an',
  templateUrl: './an.component.html',
  styleUrls: ['./an.component.css']
})
export class AnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
