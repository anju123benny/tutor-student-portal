import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AnComponent } from './an/an.component';
import { AsComponent } from './as/as.component';
import { HaiComponent } from './hai/hai.component';
  import { from } from 'rxjs';
const routes: Routes = [{path:'home',component:AnComponent},{path:'apply',component:AsComponent},{path:'login',component:HaiComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
