import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AnComponent } from './an/an.component';
import { AsComponent } from './as/as.component';
import { HaiComponent } from './hai/hai.component';
import {ViewService} from './view.service';
  import { from } from 'rxjs';
import { getViewComponent } from '@angular/core/src/render3/discovery_utils';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    AnComponent,
    AsComponent,
    HaiComponent,
    ViewService
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
