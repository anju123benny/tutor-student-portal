import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import{Form,NgForm} from '@angular/forms';
import { ViewService } from '../view.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-as',
  templateUrl: './as.component.html',
  styleUrls: ['./as.component.css']
})
export class AsComponent implements OnInit {
  student=new Student();
 error:any;
  
  isRegistered=false;
  constructor(private applyview:ViewService) { }

  ngOnInit() {
  }
apply(f:NgForm){
this.applyview.store(this.student).subscribe(data=>{
this.isRegistered=true;
console.log('Registered Successfully');
f.reset();
},(err)=>{this.error=err;
this.isRegistered=false;
});
}
}
