<?php
$con=mysql_connect("localhost","root","") or die ('unable to connect database');
mysql_select_db("project",$con) or die('could not select database');

?>