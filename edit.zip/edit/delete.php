<?php
include("conn.php");
$id=$_GET['id'];
mysql_query("delete from details where id='$id'") ;
header("Refresh:0, url=select.php");
?>

