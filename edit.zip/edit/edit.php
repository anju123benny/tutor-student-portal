
<html>
<?php
error_reporting(0);
include("conn.php");
$id=$_GET["id"];
if(isset($_POST["submit"]))
{
$name=$_POST["name"];
$address=$_POST["address"];
$phoneno=$_POST["phoneno"];

mysql_query("update details set name='$name', address='$address',phoneno='$phoneno' where id='$id'");
$sql1=mysql_query("select * from details where id='$id'");
$row=mysql_fetch_array($sql1);
}
?>
<body>
<form action="#" method="post">
<table>
<tr>
<td>name</td>
<td><input type="text" name="name" value="<?php echo $row['name'];?>" /></td>
</tr>
<tr>
<td>address</td>
<td><input type="text" name="address" value="<?php echo $row['address'];?>" /></td>
</tr>
<tr>
<td>phoneno</td>
<td><input type="text" name="phoneno" value="<?php echo $row['phoneno'];?>" /></td>
</tr>
<tr>

<td><input type="submit" name="submit" /></td>
</tr>
</table>
<form>
</body>
</html>
