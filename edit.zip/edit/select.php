
<html>
<?php
include("conn.php");
$sql1=mysql_query("select * from details");

?>
<body>
<table border="1">
<tr>
<th>Name</th>
<th>Address</th>
<th>Phoneno</th>
<th>Edit</th>
<th>Delete</th>
</tr>
<?php
while($row=mysql_fetch_array($sql1))
{
?>
<tr><td><?php echo $row['name'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['phoneno'];?></td>
<td><a href="edit.php?id=<?php echo $row["id"];?>">Edit </a></td>
<td><a href="delete.php?id=<?php echo $row["id"];?>">Delete</a></td>
</tr>
<?php
}
?>
</table>
</body>
</html>
