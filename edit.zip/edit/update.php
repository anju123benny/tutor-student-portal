<html>
<?php
include("conn.php");
$id=$_GET["id"];
if(isset($_POST["submit"]))
{
$name=$_POST["name"];
$address=$_POST["address"];
$phoneno=$_POST["phoneno"];
mysql_query("update details set name='$name', address='$address',phoneno='$phoneno' where id='$id'");
}
?>


</html>
