<html>
<?php
include("conn.php");
if(isset($_POST["submit"]))
{
$name=$_POST["name"];
$address=$_POST["address"];
$phoneno=$_POST["phoneno"];
$sql="INSERT INTO `details` ( `name`, `address`, `phoneno`) VALUES ( '$name', '$address', '$phoneno')";

$result=mysql_query($sql,$con);
	
}
?>

<body>
<form action="#" method="post">
<table>
<tr>
<td>name</td>
<td><input type="text" name="name" /></td>
</tr>
<tr>
<td>address</td>
<td><input type="text" name="address" /></td>
</tr>
<tr>
<td>phoneno</td>
<td><input type="text" name="phoneno" /></td>
</tr>
<tr>

<td><input type="submit" name="submit" /></td>
</tr>
</table>
<form>
</body>
</html>
